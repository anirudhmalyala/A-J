package com.capgemini.emp.bean;

import com.capgemini.emp.ui.*;
import java.util.regex.*;
import java.util.*; 


public class Employee {
	private static int ID;
	private static String Name;
	private static long Number;
	public static String ERole;
	public static double Salary;
	private static String Email;
	public static double TA;
	
	
	public static void setEmployeeD() 
    { 
    	Scanner sc = new Scanner(System.in); 
   	
    	System.out.println("Enter the name of the Employee: ");
        Name = sc.nextLine();     

        System.out.println("Enter Employee phone number: ");
        Number = sc.nextLong(); 

        System.out.println("Enter the Employee Role: ");
        ERole = sc.next(); 

        System.out.println("Enter the Salary: ");
        Salary = sc.nextDouble(); 

        System.out.println("Enter the Email ID: ");
        Email = sc.next(); 
    }
	
	public static void getEmployeeD()    { 
        Random random=new Random();
        ID=random.nextInt(10000);
        
        System.out.println("Employee has been successfully Register along with the "+ID);
        System.out.println("Name of the Employee: "+Name);
        System.out.println("Employee Phone Number: "+Number);
        System.out.println("Employee Role: "+ERole);
        System.out.println("Salary: "+Salary);
        System.out.println("Email ID: "+Email);

}
}
