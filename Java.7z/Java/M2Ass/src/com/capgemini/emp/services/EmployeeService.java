package com.capgemini.emp.services;
import com.capgemini.emp.bean.*;
import com.capgemini.emp.ui.*;


interface IEmployeeService{
	int addEmployee (Employee emp);
	Employee getEmployee (int empId);

}
public class EmployeeService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
