package com.cg.coreJava.beans;

public class Employee {
	
	private String name;
	
	public String getName(){
		return name;
	}
	Employee(){}
	
	void display(){
		System.out.println("ABC");
	}

	public void setName(String name) {
		// TODO Auto-generated method stub
		this.name=name;
		System.out.println("ABC");
		Employee E1=new Employee();
		E1.display();

	}

}
