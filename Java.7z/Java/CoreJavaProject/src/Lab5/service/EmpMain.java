package Lab5.service;
import Lab5.bean.*;
import Lab5.pl.*;
import Lab6.exception.*;
public class EmpMain {

public static void main(String[] args) {
Employee e1= new Employee(143,"anii",300l,"writer");
Service s= new Service();
s.methodi(20000l,"engineer");
s.display();
try
{
	if(e1.salary<3000)
		throw new EmployeeException();
}
catch(Exception e)
{
	System.out.println(e);
}
}
}
