/**
 * 
 */
/**
 * @author amalyala
 *
 */
package Lab5.q23;