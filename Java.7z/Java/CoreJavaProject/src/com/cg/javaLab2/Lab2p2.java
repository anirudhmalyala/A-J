package com.cg.javaLab2;
import java.util.Scanner;


public class Lab2p2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in); 
		int score = sc.nextInt();

        if(score > 0)
        {
            System.out.println("Your score "+score+" is Positive");
        }
        else if(score < 0)
        {
            System.out.println("Your score "+score+" is Negative");
        }
        else
        {
            System.out.println("Your score "+score+" is Neutral ");
        }

	}
}
