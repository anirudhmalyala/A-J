package com.cg.javaLab2;

import java.util.Scanner;

//enum
enum Gendr { 
M,F;
}

public class Lab2_5 {
String firstName;
String lastName;
Gendr gender;
boolean gender1;
long phone;
//constructor
Lab2_5(){
System.out.println("Person Details:"+"\n--------------\n");
}
//parameterized constructor
Lab2_5(String fname, String lname, boolean gend) {
this();
firstName = fname;
lastName = lname;
if(gend==true) {
gender = Gendr.M;
}
else {
gender = Gendr.F;
}
}
//phone setter method
void setPhone(long a) {
phone = a;
}
//phone getter method
void getPhone() {
System.out.println("Phone: "+phone);
}
//getter method
void getMethod() {
System.out.println("First Name: "+firstName+"\nLast Name: "+lastName);
System.out.println("Gender: "+gender);
getPhone();
}
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
System.out.println("Enter values");
Lab2_5 Obj = new Lab2_5(sc.next(),sc.next(),sc.nextBoolean());
Obj.setPhone(1234567890);
Obj.getMethod();
sc.close();
}
}