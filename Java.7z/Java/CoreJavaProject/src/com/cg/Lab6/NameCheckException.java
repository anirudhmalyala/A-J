package com.cg.Lab6;

import java.util.Scanner;

class InvalidNameException extends Exception

{

void check(Exception e)

{

System.out.println("You are entering an invalid name"+e);

}

}

public class NameCheckException {

public static void main(String[] args)

{

// TODO Auto-generated method stub

Person p=new Person();

/*Scanner sc=new Scanner(System.in);

String f=sc.next();

String l=sc.next();

//By getter and setter methods

p.setFirstName(f);

p.setLasttName(l);*/

p.setFirstName("");

p.setLasttName("");

System.out.println("Person Details:");

System.out.println("---------------------");

System.out.println("First Name: "+p.getFirstName());

System.out.println("Last Name: "+p.getLastName());

//System.out.println("Gender: "+p.getGender());

try

{

if(p.getLastName()=="" && p.getFirstName()=="" )

{

throw new InvalidNameException();

}

}

catch(Exception e)

{

InvalidNameException i=new InvalidNameException();

i.check(e);

}

}

}

class Person

{

String firstName,lastName;

char Gender;

Person()

{

}

Person(String f,String l,char a)

{

firstName=f;

lastName=l;

Gender=a;

}

public void setFirstName(String s)

{

firstName=s;

}

public String getFirstName()

{

return firstName;

}

public void setLasttName(String s)

{

lastName=s;

}

public String getLastName()

{

return lastName;

}

public void setGender(char c)

{

Gender=c;

}

public char getGender()

{

return Gender;

}

}
