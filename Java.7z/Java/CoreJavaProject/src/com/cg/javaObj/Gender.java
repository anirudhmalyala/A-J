package com.cg.javaObj;

public enum Gender {
M,F, O;
}
