package com.cg.javaObj;

public class This90 {
	int a=10, b=20,c;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		This90 t= new This90();
		t.show();
		//System.out.println(t.b);
	}
	 void show(){
		int b=40,c=50;
		System.out.println(a);
		System.out.println(this.a);
		System.out.println(b);
	    //System.out.println(t.b);
		System.out.println(this.b);
		System.out.println(c);
	}

}
