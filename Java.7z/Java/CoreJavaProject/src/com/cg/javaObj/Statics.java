package com.cg.javaObj;

public class Statics {
	void m(){
		System.out.println(this);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Statics obj= new Statics();
	Statics obj2= new Statics();
		System.out.println(obj);
		System.out.println(obj2);
		obj.m();
		obj2.m();
	}

}
