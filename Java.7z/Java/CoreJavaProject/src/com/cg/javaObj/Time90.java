package com.cg.javaObj;

public class Time90 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
