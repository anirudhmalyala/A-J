package com.cg.operators;

class Company{
	String k= "Parent's, here!";
}

public class Inh1 extends Company{
	public void check(){
		System.out.println("TADA! " +k);
	}
	public void view(Company c){
		if(c instanceof Inh1){
			Inh1 b1=(Inh1) c;
			b1.check();
			System.out.println("TADA! " +k);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Inh1 c= new Inh1();
		Inh1 d= new Inh1();
		d.view(c);

	}

}