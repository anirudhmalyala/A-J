package com.cg.operators;

public class IncDec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int var=10;
		System.out.println(var++);
		System.out.println(++var);
		System.out.println(var--);
		System.out.println(--var);

	}

}
