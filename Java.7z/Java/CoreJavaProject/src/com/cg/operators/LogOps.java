package com.cg.operators;

public class LogOps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean a=true, b=false;
		System.out.println("a&&b is "+(a&&b));
		System.out.println("a||b is "+(a||b));
		System.out.println("!(a&&b) is "+(!(a&&b)));	
		System.out.println("!(a||b) is "+(!(a||b)));
	}

}
