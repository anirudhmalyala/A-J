package com.cg.Lab8;

import java.util.*;
import java.io.*;
import java.lang.*;

public class FileIOScanner {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		
		try {
            System.out.print("Enter file name with extension: ");

            Scanner input = new Scanner(System.in);

            File file = new File(input.nextLine());
            input = new Scanner(file);

            while (input.hasNextLine()) {
                String line = input.nextLine();
                System.out.println(line);
            }
            input.close();

        }
		catch (Exception ex) {
            ex.printStackTrace();
        }
		
		
		
    }

}
