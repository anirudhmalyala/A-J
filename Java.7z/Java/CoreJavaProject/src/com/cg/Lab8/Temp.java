package com.cg.Lab8;

import java.util.*;
import java.io.*;


public class Temp {

    public static void main(String[] args) throws Exception {
        Scanner input = null;
        try {
            input = new Scanner(new File("D:\\number.txt"));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
   
        List<Integer> list=new ArrayList<Integer>();
        
        while(input.hasNextInt()) {
            list.add(input.nextInt());
        }
        System.out.println("File to ArrayList: "+list);
        System.out.println("Even String");
        for(int i=0;i<list.size();i++)
        	if(list.get(i)%2==0)
        		System.out.println(list.get(i));
    }
}
	