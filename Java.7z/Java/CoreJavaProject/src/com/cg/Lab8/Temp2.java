package com.cg.Lab8;
import java.util.*;
import java.io.*;
import java.lang.*;

public class Temp2
{
 
public static void main(String[] args) throws IOException
{
File fileToRead = new File("D:\\numbers.txt");
Scanner content=new Scanner(fileToRead);
 
String s=content.nextLine();
StringTokenizer st = new StringTokenizer(s,",");
while (st.hasMoreTokens())
{
int i=Integer.parseInt(st.nextToken());
if(i%2==0)
System.out.println(i);
 
 
}
}
}
