package com.cg.Lab4;
import java.util.*;

class Person extends Account{
	float age;
	
	Person(int aNo, String aHo, double bal,  float ag)
	{
		accNum=aNo;
		balance=bal;
		accHolder=aHo;
		age=ag;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random random=new Random();
		accNum=random.nextInt(10000);
		
		Person a=new Person(accNum,"Smith",2000,45);
		Person b=new Person(accNum,"Kethy",3000,40);
		
		a.display();
		b.accNum=a.accNum+1;
		b.display();
		
		a.setDeposit(2000);
		b.getWithdraw(3000);
		a.getBalance();
		b.getBalance();
		
		System.out.println("\nUpdated BalanceSheet\n--------------------");
		
		a.accNum=b.accNum-1;
		a.display();
		b.accNum=a.accNum+1;
		b.display();
		
		System.out.println("\n\n"+a.toString());
		System.out.println(b.toString());

	}

}
