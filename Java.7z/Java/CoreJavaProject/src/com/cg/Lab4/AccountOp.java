package com.cg.Lab4;

public class AccountOp 	
{	
	public static void main(String args[])
	{
		SavingsAccount sAcc=new SavingsAccount();
		sAcc.getWithdraw(1000.00); //as the type id double so enter double value
		CurrentAccount cAcc= new CurrentAccount();
		cAcc.getWithdraw(1900.00);
		cAcc.getWithdraw(1000.00);
		cAcc.getWithdraw(200.00);
		}
		}