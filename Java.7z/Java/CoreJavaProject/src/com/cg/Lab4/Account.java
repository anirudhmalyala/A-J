package com.cg.Lab4;


public class Account {
	static int accNum;
	double balance=500;
	String accHolder;
	
	void setDeposit(double d){
		balance+=d;
		
	}
	void getWithdraw(double w){
		if(balance>=500){
			balance-=w;
		}
		else System.out.println("Insufficient balance.");

	}
	double getBalance(){
		return balance;
		
	}
	void display(){
		
		System.out.println(accNum+"		"+accHolder+"		"+balance);
	}
	/*Account(long aNo, double bal, String aHo)
	{
		accNum=aNo;
		balance=bal;
		accHolder=aHo;		
	}*/


}
