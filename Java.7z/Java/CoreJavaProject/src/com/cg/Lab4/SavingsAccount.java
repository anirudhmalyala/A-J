package com.cg.Lab4;

class Acc{
	long accNum;
	double balance=2000;


void display(){
	System.out.println("Your balance is "+balance);
}
}
class SavingsAccount extends Acc {
	
	double minimumBalance=500;
	
	void getWithdraw(double mB)
	{
		if((balance-mB)<500)
			System.out.println("Withdraw Limit Exception");
		else
		{
			balance=balance-mB;
			display();
		}
	}	
}