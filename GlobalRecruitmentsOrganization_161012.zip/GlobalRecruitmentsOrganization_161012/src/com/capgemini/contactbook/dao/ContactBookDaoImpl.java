package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.utility.JdbcUtility;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao {

	static Logger logger = Logger.getLogger(ContactBookDaoImpl.class);
	Connection connection = null;
	PreparedStatement statement = null;

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {

		logger.info("in enquiry method..");
		int enquiryId = 0;
		connection = JdbcUtility.getConnection();

		try {

			statement = connection.prepareStatement(QueryConstants.insertQuery);
			statement.setString(1, enqry.getfName());
			statement.setString(2, enqry.getlName());
			statement.setLong(3, Long.parseLong(enqry.getContactNo()));
			statement.setString(4, enqry.getpDomain());
			statement.setString(5, enqry.getpLocation());
			statement.executeUpdate();

			statement = connection.prepareStatement(QueryConstants.getIdQuery);

			ResultSet resultSet = statement.executeQuery();
			resultSet.next();
			enquiryId = resultSet.getInt(1);
		} catch (SQLException e) {
			logger.error("statement not created1..");
			throw new ContactBookException("statement not created1");
		}
		return enquiryId;

	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
		logger.info("in getting enquiry details method..");
		connection = JdbcUtility.getConnection();

		try {

			statement = connection
					.prepareStatement(QueryConstants.getEnquiryDetailsQuery);
			statement.setInt(1, EnquiryID);
			// System.out.println("qwfjkhgwj");
			ResultSet resultSet = statement.executeQuery();
			resultSet.next();
			EnquiryBean e = new EnquiryBean();
			e.setEnqryId(resultSet.getInt(1));
			e.setfName(resultSet.getString(2));
			e.setlName(resultSet.getString(3));
			e.setContactNo(String.valueOf(resultSet.getInt(4)));
			e.setpDomain(resultSet.getString(5));
			e.setpLocation(resultSet.getString(6));
			return e;
		}

		catch (SQLException e1) {
			logger.error("statement not created99..");
			throw new ContactBookException("Not there in db");
		}

	}
}
