package com.capgemini.contactbook.exceptions;

public class ContactBookException extends Exception {
	private String message;

	public ContactBookException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
