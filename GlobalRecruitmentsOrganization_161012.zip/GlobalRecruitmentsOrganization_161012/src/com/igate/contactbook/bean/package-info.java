/**
 * 
 */
/**
 * @author amalyala
 *
 */
package com.igate.contactbook.bean;