package com.capgemini.tcc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exceptions.ClinicException;

public class PatientService implements IPatientService {

	IPatientDAO dao = new PatientDAO();

	// -----------------------------------------------------------------------------------------------------------
	@Override
	public int addPatientDetails(PatientBean patient) throws ClinicException {

		return dao.addPatientDetails(patient);
	}

	// -----------------------------------------------------------------------------------------------------------
	@Override
	public PatientBean getPatientDetails(int patientId) throws ClinicException {
		
		return dao.getPatientDetails(patientId);
	}

	// -----------------------------------------------------------------------------------------------------------

	@Override
	public boolean validateDetails(PatientBean patient) throws ClinicException {

		List<String> list = new ArrayList<>();
		boolean result = false;

		if (!validatePatientName(patient.getPatientName())) {
			list.add("Name should start with a Capital-letter and the length should be in between 6 and 20");
		}
		if (!validateAge(patient.getAge())) {
			list.add("Give age properly.");
		}
		if (!validatePhoneNumber(patient.getPhoneNumber())) {
			list.add("The Phone number should be exactly 10 digits");
		}

		if (!list.isEmpty()) {
			result = false;
			throw new ClinicException(list + "");
		} else {
			result = true;
		}
		return result;
	}

	public boolean validatePatientName(String patientName) {

		String patientNameRegEx = "[A-Z]{1}[a-zA-Z]{5,20}";
		Pattern pattern = Pattern.compile(patientNameRegEx);
		Matcher matcher = pattern.matcher(patientName);
		return matcher.matches();
	}

	public boolean validateAge(int age) {

		String ageRegEx = "[0-9]{1,3}";
		Pattern pattern = Pattern.compile(ageRegEx);
		Matcher matcher = pattern.matcher(String.valueOf(age));
		return matcher.matches();
	}

	public boolean validatePhoneNumber(long phoneNumber) {

		String phoneNumberRegEx = "[1-9]{1}[0-9]{9}";
		Pattern pattern = Pattern.compile(phoneNumberRegEx);
		Matcher matcher = pattern.matcher(String.valueOf(phoneNumber));
		return matcher.matches();
	}

}
