package com.capgemini.tcc.dao;

public interface QueryConstants {
	public static final String insertQuery = "INSERT INTO Patient VALUES(Patient_Id_Seq.nextval,?,?,?,?,sysdate+1)";
	public static final String getIdQuery = "SELECT max(patient_id) FROM Patient";
	public static final String detailsQuery = "SELECT * FROM Patient WHERE patient_id=?";
}
