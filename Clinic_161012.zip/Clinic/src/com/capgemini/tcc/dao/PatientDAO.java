package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exceptions.ClinicException;
import com.capgemini.tcc.utility.JdbcUtility;

public class PatientDAO implements IPatientDAO {
	static Logger logger = Logger.getLogger(PatientDAO.class);

	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;

	// -----------------------------------------------------------------------------------------------------------
	@Override
	public int addPatientDetails(PatientBean patient) throws ClinicException {
		logger.info("Inserting the details into the database");

		int patientId = 0;
		connection = JdbcUtility.getConnection();

		try {
			statement = connection.prepareStatement(QueryConstants.insertQuery);
			statement.setString(1, patient.getPatientName());
			statement.setInt(2, patient.getAge());
			statement.setLong(3, patient.getPhoneNumber());
			statement.setString(4, patient.getDescription());
			statement.executeUpdate();

			statement = connection.prepareStatement(QueryConstants.getIdQuery);
			resultSet = statement.executeQuery();
			resultSet.next();
			patientId = resultSet.getInt(1);

		} catch (SQLException e) {
			logger.error("The statement is not created.");
			throw new ClinicException("The statement is not created.");
		}
		return patientId;
	}

	// -----------------------------------------------------------------------------------------------------------
	@Override
	public PatientBean getPatientDetails(int patientId) throws ClinicException {
		logger.info("Getting details of patient using Patient ID");

		connection = JdbcUtility.getConnection();
		String doctorName = "";

		try {
			statement = connection
					.prepareStatement(QueryConstants.detailsQuery);
			statement.setInt(1, patientId);

			resultSet = statement.executeQuery();
			resultSet.next();
			PatientBean patient = new PatientBean();

			patient.setPatientId(resultSet.getInt(1));
			patient.setPatientName(resultSet.getString(2));
			patient.setAge(resultSet.getInt(3));
			patient.setPhoneNumber(resultSet.getLong(4));
			patient.setDescription(resultSet.getString(5));
			patient.setConsultationDate(resultSet.getDate(6));

			return patient;

		} catch (SQLException e) {
			logger.error("There is no Patient with this ID");
			throw new ClinicException("There is no Patient with this ID");
		}
	}

}
