package com.capgemini.tcc.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exceptions.ClinicException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client {
	static Logger logger = Logger.getLogger(Client.class);

	public static void main(String[] args) throws ClinicException {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j file loaded...");
		Scanner scanner = new Scanner(System.in);

		IPatientService service = new PatientService();
		while (true) {
			System.out.println("1.		Add Patient Information");
			System.out.println("2.		Search patient by Id");
			System.out.println("3.		Exit");

			System.out.println("Select your choice");
			int choice = 0;
			try {
				choice = scanner.nextInt();
			} catch (InputMismatchException e) {
				System.err.println("Enter only digits");
				System.exit(0);
			}
			switch (choice) {
			case 1:
				scanner.nextLine();
				System.out.println("Enter the name of the Patient: ");
				String patientName = scanner.nextLine();
				System.out.println("Enter the Patient Age:");
				int age = 0;
				try {
					age = scanner.nextInt();
				} catch (InputMismatchException e) {
					System.err.println("Age should be digits only");
					System.exit(0);
				}
				System.out.println("Enter the Patient Mobile Number:");
				long phoneNumber = 0;
				try {
					phoneNumber = scanner.nextLong();
				} catch (InputMismatchException e) {
					System.err
							.println("Phone number should contain digits only");
					System.exit(0);
				}
				scanner.nextLine();
				System.out.println("Enter the Description:");
				String description = scanner.nextLine();

				PatientBean patient = new PatientBean();
				patient.setPatientName(patientName);
				patient.setAge(age);
				patient.setPhoneNumber(phoneNumber);
				patient.setDescription(description);
				try {
					boolean result = service.validateDetails(patient);

					if (result) {
						int patientId = service.addPatientDetails(patient);
						System.out
								.println("Patient Information stored successfully for "
										+ patientId);
					}

				} catch (ClinicException e) {
					System.err.println(e.getMessage());
				}
				break;
			case 2:
				System.out.print("Enter the Patient ID: ");
				int patientId = 0;
				try {
					patientId = scanner.nextInt();
				} catch (InputMismatchException e) {
					System.err.println("Enter only digits");
					System.exit(0);
				}

				PatientBean searchPatient;
				try {
					searchPatient = service.getPatientDetails(patientId);
					System.out.println(searchPatient);

				} catch (ClinicException e) {
					System.err.println(e.getMessage());
				}

				break;
			case 3:
				System.out.println("Exited from operation successfully");
				System.exit(0);
				break;
			default:

				System.out.println("Invalid option");
				break;
			}

		}
	}

}
