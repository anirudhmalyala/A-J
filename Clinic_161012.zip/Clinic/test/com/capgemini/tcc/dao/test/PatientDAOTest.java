package com.capgemini.tcc.dao.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exceptions.ClinicException;

public class PatientDAOTest {

	PatientDAO patientDao = null;

	@Before
	public void setUp() {
		patientDao = new PatientDAO();
	}

	@After
	public void tearDown() {
		patientDao = null;
	}

	@Test
	public void addPatientDetails() {

		PatientBean patient = new PatientBean();
		patient.setPatientName("Anirudh");
		patient.setAge(12);
		patient.setPhoneNumber(909099876l);
		patient.setDescription("asdasd");
		try {
			Integer id = patientDao.addPatientDetails(patient);
			assertNotNull(id);

		} catch (ClinicException e) {
			System.err.println("11111");
		}
	}

	@Test
	public void getPatientDetails() {
		PatientBean searchPatient;

		try {
			searchPatient = patientDao.getPatientDetails(1002);
			assertEquals("Anirudh", searchPatient.getPatientName());
		} catch (ClinicException e) {
			System.err.println("2222");
		}

	}
}
